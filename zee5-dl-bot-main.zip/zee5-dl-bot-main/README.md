# zee5-dl-bot and mx player movies
heroku deploy create your own from fork and deploy connect your github
API_HASH
TG_BOT_TOKEN
APP_ID
who want to add these in reveal config
support my YouTube channel for more open source code 
https://m.youtube.com/channel/UCLHZQApnu1vN2j7fKDgv74w
demo at https://t.me/infinitrotorrenticBot
<img src="https://github.com/Nirmalraj10567/zee5-dl-bot/raw/main/Download/2020-11-29_13_24_35.jpg"></img>
